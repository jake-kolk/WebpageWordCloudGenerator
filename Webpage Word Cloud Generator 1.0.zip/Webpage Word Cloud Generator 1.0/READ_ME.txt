This is a preview, its probably going to be a little broken. 

HOW TO USE:
Prerequisite knowledge
-Be sure to keep all files INSIDE the "Webpage Word Cloud Generator 1.0" folder
-"MIT10K" is a list of the 10k most commonly used English words, and its used to validate all the scanned words. MIT10K must contain a word for it to be included in the word cloud. You can add or remove words by MIT10K this document.
-The .txt files this program can generate consist of all the scanned words from the web page, and all the scanned words plus their frequency (in .csv format)
ACTUAL USE
-Extract all the contents of "Webpage Word Cloud Generator 1.0" into a folder
-Double click on the .exe file in the EXTRACTED "Webpage Word Cloud Generator 1.0" folder
-Once the program launches, you are able to adjust the values of the text boxes, sliders, and check boxes to tailor your word cloud.